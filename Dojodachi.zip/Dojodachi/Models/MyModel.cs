using System;

namespace Dojodachi.Models
{
    public class Dachi 
    {
    //    private static Random rand = new Random();
       public int Happiness {get; set;}
       public int Fullness {get; set;}
       public int Energy {get;set;}
       public int Meals {get;set;}
       public string Message {get;set;}


    }
}